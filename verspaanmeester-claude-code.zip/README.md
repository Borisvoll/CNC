# VerspaanMeester

Werkplaats-companion voor CNC en conventioneel verspanen. Gebouwd voor studenten aan de Leidse Instrumentmakers School.

## Wat is dit?

Een webapp die je meeneemt naar de machine. Geen quiz-app, maar een gereedschap:

- **Werkplaatsopdrachten** — 15 opdrachten die je aan de echte machine uitvoert, met hypothese → experiment → observatie → conclusie
- **Rekenmachine** — snijdata berekenen voor draaien en frezen
- **Diagnose** — symptoom aanklikken → oorzaken en acties
- **Naslagwerk** — formules, parameters, ISO-materiaalgroepen, toleranties, G-code referentie (Fanuc + Mazak)
- **Logboek** — je notities worden lokaal opgeslagen

## Hoe gebruiken?

### Online (GitHub Pages)
Ga naar: `https://[jouw-gebruikersnaam].github.io/verspaanmeester/`

### Lokaal
Download `index.html` en open het in je browser. Meer is niet nodig.

## Hoe deployen op GitHub Pages?

1. Maak een nieuwe repository op GitHub (bijv. `verspaanmeester`)
2. Upload `index.html` naar de repository
3. Ga naar **Settings → Pages**
4. Onder "Source" kies **Deploy from a branch**
5. Kies **main** branch en **/ (root)** folder
6. Klik **Save**
7. Na ~1 minuut staat je app live op `https://[gebruikersnaam].github.io/verspaanmeester/`

## Technisch

- Pure HTML + React via CDN
- Geen build-stap nodig
- Geen server nodig
- Geen API keys
- Logboek opgeslagen in localStorage (blijft staan in je browser)
- Werkt offline na eerste keer laden

## Kennisbasis

Gebaseerd op:
- Sandvik Coromant MTG (Metal Turning Guide) A t/m I
- Shigley's Mechanical Engineering Design, 10th Edition
- Kennisbasis CNC Verspanen AI-bundle v2

## Licentie

Vrij te gebruiken voor educatieve doeleinden.
